var ref = new Firebase("https://pblshn.firebaseio.com");
        ref.child("meta").once("value", function(snapshot) {
          $("#feed > :first").html(snapshot.val().description);
        });
        ref.child("articles").limit(10).on("child_added", function(snapshot) {
          var article = snapshot.val();
          var link = $("<a>", {"href": article.link, "target": "_blank"});
          $("#feed").append($("<li>").append(link.html(article.title)));
          $('#feed').listview('refresh');
        });
        
        //popup code
        
        $('#whatis').click (function() {
            $(this).simpledialog({
                'mode' : 'blank',
                'prompt': false,
                'forceInput': false,
                'useModal':true,
                'fullHTML' : 
                    "<ul data-role='listview'><li>Some</li><li>List</li><li>Items</li></ul><a rel='close' data-role='button' href='#' id='simpleclose'>Close</a>"
            })
        });